import { Link } from "react-router-dom";

export function NotFoundPage() {
  return (
    <div className="page" style={{ textAlign: "center" }}>
      <h1>404</h1>
      <p className="muted">This page doesn't exist.</p>
      <Link to="/" className="btn">Go home</Link>
    </div>
  );
}
