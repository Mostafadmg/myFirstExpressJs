import { useState, useEffect } from "react";
import { useParams, Link } from "react-router-dom";
import { getListingById } from "../../api/listingsApi.js";
import { getReviewsForListing, createReview } from "../../api/reviewsApi.js";
import { getCommentsForListing, createComment } from "../../api/commentsApi.js";
import { addToCart } from "../../api/cartApi.js";
import { addFavorite } from "../../api/favoritesApi.js";
import { LoadingSpinner } from "../../components/common/LoadingSpinner.jsx";
import { ErrorMessage } from "../../components/common/ErrorMessage.jsx";
import { RatingStars } from "../../components/common/RatingStars.jsx";
import { formatCurrency } from "../../utils/formatters.js";
import { LISTING_TYPE } from "../../utils/constants.js";
import { useAuth } from "../../hooks/useAuth.js";

export function ListingDetailPage() {
  const { id } = useParams();
  const { currentUser } = useAuth();

  const [listing, setListing] = useState(null);
  const [reviews, setReviews] = useState([]);
  const [comments, setComments] = useState([]);
  const [status, setStatus] = useState("loading");
  const [error, setError] = useState(null);

  // Runs again whenever `id` changes (navigating from one listing straight
  // to another re-triggers this effect because `id` is in the dependency
  // array) — that's the correct, intentional use of a dependency array,
  // unlike the earlier bug where the effect depended on its own output.
  useEffect(() => {
    setStatus("loading");
    Promise.all([getListingById(id), getReviewsForListing(id), getCommentsForListing(id)])
      .then(([listingData, reviewsData, commentsData]) => {
        setListing(listingData);
        setReviews(reviewsData);
        setComments(commentsData);
        setStatus("success");
      })
      .catch((err) => {
        setError(err);
        setStatus("error");
      });
  }, [id]);

  async function handleAddToCart() {
    await addToCart(id, 1);
  }

  async function handleFavorite() {
    await addFavorite(id);
  }

  async function handleReviewSubmit(e) {
    e.preventDefault();
    const form = new FormData(e.target);
    const review = await createReview(id, Number(form.get("rating")), form.get("comment"));
    setReviews((prev) => [...prev, review]);
    e.target.reset();
  }

  async function handleCommentSubmit(e) {
    e.preventDefault();
    const form = new FormData(e.target);
    const comment = await createComment(id, form.get("text"));
    setComments((prev) => [...prev, comment]);
    e.target.reset();
  }

  if (status === "loading") return <div className="page"><LoadingSpinner /></div>;
  if (status === "error") return <div className="page"><ErrorMessage error={error} /></div>;

  return (
    <div className="page">
      <Link to="/" className="muted">&larr; Back to browse</Link>
      <h1>{listing.title}</h1>
      <p className="muted">{listing.category}</p>
      <p>{listing.description}</p>
      <h2>{formatCurrency(listing.priceInCents)}</h2>

      {currentUser && listing.type === LISTING_TYPE.PRODUCT && (
        <div className="row">
          <button className="btn" onClick={handleAddToCart}>Add to cart</button>
          <button className="btn secondary" onClick={handleFavorite}>Save to favorites</button>
        </div>
      )}

      {currentUser && listing.type === LISTING_TYPE.SERVICE && (
        <Link to={`/bookings/new?listingId=${id}`} className="btn">Check availability &amp; book</Link>
      )}

      <h3>Reviews <RatingStars rating={listing.averageRating} /></h3>
      {reviews.map((review) => (
        <div key={review.id} className="card" style={{ marginBottom: 8 }}>
          <RatingStars rating={review.rating} /> <p>{review.comment}</p>
        </div>
      ))}
      {currentUser && (
        <form onSubmit={handleReviewSubmit} className="card">
          <div className="field">
            <label>Rating (1-5)</label>
            <input name="rating" type="number" min="1" max="5" required />
          </div>
          <div className="field">
            <label>Comment</label>
            <textarea name="comment" rows="3" />
          </div>
          <button className="btn" type="submit">Submit review</button>
        </form>
      )}

      <h3>Comments</h3>
      {comments.map((comment) => (
        <p key={comment.id} className="muted">{comment.text}</p>
      ))}
      {currentUser && (
        <form onSubmit={handleCommentSubmit} className="row">
          <input name="text" placeholder="Add a comment..." required />
          <button className="btn secondary" type="submit">Post</button>
        </form>
      )}
    </div>
  );
}
