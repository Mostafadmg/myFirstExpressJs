import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { createListing, uploadListingPhotos } from "../../api/listingsApi.js";
import { getCategories } from "../../api/categoriesApi.js";
import { PhotoUploader } from "../../components/common/PhotoUploader.jsx";
import { ErrorMessage } from "../../components/common/ErrorMessage.jsx";
import { LISTING_TYPE } from "../../utils/constants.js";

export function CreateListingPage() {
  const navigate = useNavigate();
  const [categories, setCategories] = useState([]);
  const [error, setError] = useState(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [createdListingId, setCreatedListingId] = useState(null);

  useEffect(() => {
    getCategories().then(setCategories).catch(() => setCategories([]));
  }, []);

  async function handleSubmit(e) {
    e.preventDefault();
    setError(null);
    setIsSubmitting(true);
    const form = new FormData(e.target);
    try {
      const listing = await createListing({
        title: form.get("title"),
        description: form.get("description"),
        priceInCents: Math.round(Number(form.get("price")) * 100),
        category: form.get("category"),
        type: form.get("type"),
        stock: form.get("type") === LISTING_TYPE.PRODUCT ? Number(form.get("stock")) : undefined,
      });
      setCreatedListingId(listing.id);
    } catch (err) {
      setError(err);
    } finally {
      setIsSubmitting(false);
    }
  }

  // Two-step flow on purpose: the listing needs an id (assigned by
  // Express/Postgres) BEFORE photos can be attached to it, so photo
  // upload only becomes available after the create request succeeds.
  if (createdListingId) {
    return (
      <div className="page" style={{ maxWidth: 480 }}>
        <h1>Add photos</h1>
        <PhotoUploader multiple onUpload={(files) => uploadListingPhotos(createdListingId, files)} label="Listing photos" />
        <button className="btn" onClick={() => navigate(`/listings/${createdListingId}`)}>
          Done
        </button>
      </div>
    );
  }

  return (
    <div className="page" style={{ maxWidth: 480 }}>
      <h1>Create a listing</h1>
      <form onSubmit={handleSubmit} className="card">
        <div className="field">
          <label>Title</label>
          <input name="title" required />
        </div>
        <div className="field">
          <label>Description</label>
          <textarea name="description" rows="4" required />
        </div>
        <div className="field">
          <label>Price (USD)</label>
          <input name="price" type="number" step="0.01" min="0" required />
        </div>
        <div className="field">
          <label>Category</label>
          <select name="category" required>
            {categories.map((c) => (
              <option key={c.id} value={c.id}>{c.name}</option>
            ))}
          </select>
        </div>
        <div className="field">
          <label>Type</label>
          <select name="type" required>
            <option value={LISTING_TYPE.PRODUCT}>Physical product (has stock)</option>
            <option value={LISTING_TYPE.SERVICE}>Bookable service (has availability)</option>
          </select>
        </div>
        <div className="field">
          <label>Stock (products only)</label>
          <input name="stock" type="number" min="0" />
        </div>
        {error && <ErrorMessage error={error} />}
        <button className="btn" type="submit" disabled={isSubmitting}>
          {isSubmitting ? "Creating..." : "Create listing"}
        </button>
      </form>
    </div>
  );
}
