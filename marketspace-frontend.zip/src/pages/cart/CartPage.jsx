import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { getCart, updateCartItem, removeFromCart } from "../../api/cartApi.js";
import { LoadingSpinner } from "../../components/common/LoadingSpinner.jsx";
import { ErrorMessage } from "../../components/common/ErrorMessage.jsx";
import { EmptyState } from "../../components/common/EmptyState.jsx";
import { formatCurrency } from "../../utils/formatters.js";

export function CartPage() {
  const navigate = useNavigate();
  const [cart, setCart] = useState(null);
  const [status, setStatus] = useState("loading");
  const [error, setError] = useState(null);

  useEffect(() => {
    loadCart();
  }, []);

  function loadCart() {
    setStatus("loading");
    getCart()
      .then((data) => {
        setCart(data);
        setStatus("success");
      })
      .catch((err) => {
        setError(err);
        setStatus("error");
      });
  }

  async function handleQuantityChange(listingId, quantity) {
    await updateCartItem(listingId, quantity);
    loadCart();
  }

  async function handleRemove(listingId) {
    await removeFromCart(listingId);
    loadCart();
  }

  if (status === "loading") return <div className="page"><LoadingSpinner /></div>;
  if (status === "error") return <div className="page"><ErrorMessage error={error} onRetry={loadCart} /></div>;
  if (cart.items.length === 0) return <div className="page"><EmptyState message="Your cart is empty." actionLabel="Browse listings" onAction={() => navigate("/")} /></div>;

  return (
    <div className="page">
      <h1>Your cart</h1>
      {cart.items.map((item) => (
        <div key={item.listingId} className="card row" style={{ justifyContent: "space-between", marginBottom: 8 }}>
          <Link to={`/listings/${item.listingId}`}>{item.title}</Link>
          <input
            type="number"
            min="1"
            value={item.quantity}
            style={{ width: 70 }}
            onChange={(e) => handleQuantityChange(item.listingId, Number(e.target.value))}
          />
          <span>{formatCurrency(item.price * item.quantity)}</span>
          <button className="btn danger" onClick={() => handleRemove(item.listingId)}>Remove</button>
        </div>
      ))}
      <div className="row" style={{ justifyContent: "space-between" }}>
        <h3>Total: {formatCurrency(cart.total)}</h3>
        <Link to="/checkout" className="btn">Checkout</Link>
      </div>
    </div>
  );
}
