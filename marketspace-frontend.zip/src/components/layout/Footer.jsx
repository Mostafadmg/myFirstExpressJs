export function Footer() {
  return (
    <footer className="page muted" style={{ textAlign: "center" }}>
      Marketspace — a practice project for learning Express.js and PostgreSQL.
    </footer>
  );
}
