import { Link } from "react-router-dom";
import { useAuth } from "../../hooks/useAuth.js";
import { ROLES } from "../../utils/constants.js";
import { RoleGate } from "../common/RoleGate.jsx";

export function Navbar() {
  const { currentUser, logout } = useAuth();

  return (
    <header className="row" style={{ justifyContent: "space-between", padding: "12px 16px", background: "white", borderBottom: "1px solid #e5e5e8" }}>
      <div className="row">
        <Link to="/" style={{ fontWeight: 700 }}>Marketspace</Link>
        <Link to="/">Browse</Link>
        <RoleGate allow={[ROLES.SELLER, ROLES.ADMIN]}>
          <Link to="/listings/new">Sell / Offer</Link>
        </RoleGate>
      </div>
      <div className="row">
        {currentUser ? (
          <>
            <Link to="/notifications">Notifications</Link>
            <Link to="/messages">Messages</Link>
            <Link to="/cart">Cart</Link>
            <Link to="/orders">Orders</Link>
            <Link to="/bookings">Bookings</Link>
            <Link to={`/profile/${currentUser.id}`}>Profile</Link>
            <RoleGate allow={[ROLES.ADMIN]}>
              <Link to="/admin">Admin</Link>
            </RoleGate>
            <button className="btn secondary" onClick={logout}>Log out</button>
          </>
        ) : (
          <>
            <Link to="/login">Log in</Link>
            <Link to="/register">Sign up</Link>
          </>
        )}
      </div>
    </header>
  );
}
