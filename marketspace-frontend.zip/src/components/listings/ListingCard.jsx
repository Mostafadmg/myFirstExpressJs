import { Link } from "react-router-dom";
import { formatCurrency } from "../../utils/formatters.js";
import { RatingStars } from "../common/RatingStars.jsx";

export function ListingCard({ listing }) {
  return (
    <Link to={`/listings/${listing.id}`} className="card">
      <div style={{ height: 120, background: "#eee", borderRadius: 6, marginBottom: 8 }}>
        {listing.photoUrl && (
          <img src={listing.photoUrl} alt={listing.title} style={{ width: "100%", height: "100%", objectFit: "cover", borderRadius: 6 }} />
        )}
      </div>
      <strong>{listing.title}</strong>
      <p className="muted" style={{ margin: "4px 0" }}>{listing.category}</p>
      <div className="row" style={{ justifyContent: "space-between" }}>
        <span>{formatCurrency(listing.priceInCents)}</span>
        <RatingStars rating={listing.averageRating} />
      </div>
    </Link>
  );
}
