export function ErrorMessage({ error, onRetry }) {
  const message = typeof error === "string" ? error : error?.message || "Something went wrong.";
  return (
    <div className="card" style={{ borderColor: "#f3c2c2", background: "#fff5f5" }}>
      <p style={{ margin: 0 }}>{message}</p>
      {onRetry && (
        <button className="btn secondary" style={{ marginTop: 8 }} onClick={onRetry}>
          Try again
        </button>
      )}
    </div>
  );
}
