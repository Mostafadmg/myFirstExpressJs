export function LoadingSpinner({ label = "Loading..." }) {
  return <p className="muted">{label}</p>;
}
