import { request } from "./config.js";

// Expects: GET /api/listings?category=&type=&minPrice=&maxPrice=&sort=&page=&limit=&q=
// Returns: { listings: [...], total, page, totalPages }
// This one endpoint is where filtering + sorting + searching + pagination
// all meet — a great place to practice building a query-string-driven
// Express route with a dynamic WHERE clause later.
export async function getListings(filters = {}) {
  const params = new URLSearchParams(filters);
  return request(`/listings?${params.toString()}`);
}

// Expects: GET /api/listings/:id
export async function getListingById(listingId) {
  return request(`/listings/${listingId}`);
}

// Expects: POST /api/listings  body: { title, description, price, category, type, stock? }
export async function createListing(listing) {
  return request("/listings", { method: "POST", body: listing });
}

// Expects: PATCH /api/listings/:id  body: partial listing fields
export async function updateListing(listingId, updates) {
  return request(`/listings/${listingId}`, { method: "PATCH", body: updates });
}

// Expects: DELETE /api/listings/:id
export async function deleteListing(listingId) {
  return request(`/listings/${listingId}`, { method: "DELETE" });
}

// Expects: POST /api/listings/:id/photos  multipart/form-data, field "photos" (multiple)
export async function uploadListingPhotos(listingId, files) {
  const formData = new FormData();
  for (const file of files) formData.append("photos", file);
  return request(`/listings/${listingId}/photos`, { method: "POST", body: formData, isFormData: true });
}

// Expects: GET /api/listings/mine  (current seller's own listings)
export async function getMyListings() {
  return request("/listings/mine");
}
